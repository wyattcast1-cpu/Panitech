PaniTech Supabase version

Upload index.html to the GitHub repository connected to Vercel. Vercel will redeploy automatically.

The page is configured for the supplied Supabase project and uses the client publishable key. It requires the classrooms, lessons, quizzes, and scores tables created earlier.

Cover photos are stored as base64 in lessons.cover_photo (TEXT), limited to 3MB in this starter version.
Never put a Supabase service_role/secret key in frontend code.
